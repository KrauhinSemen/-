package com.example.diplom_work;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Music_table extends AppCompatActivity {

    // Класс для каждого инструмента
    private class Musical_instrument {
        private int note;
        private int octave;
        private int id;
        private int x_position;
        private int y_position;
        private int width;
        private int height;

        public Musical_instrument(int id, int x, int y) {
            this.id = id;
            this.octave = -1;
            this.note = -1;
            this.width = 100;
            this.height = 100;
            this.x_position = x;
            this.y_position = y;
        }

        public Musical_instrument(int id, int x, int y, int octave, int note, int width, int height) {
            this.id = id;
            this.octave = octave;
            this.note = note;
            this.width = width;
            this.height = height;
            this.x_position = x;
            this.y_position = y;
        }

        public String To_string() {
            return this.id + " " + x_position + " " + y_position + " " + octave + " " + note + " " + width + " " + height;
        }

    }

    private ConstraintLayout field;
//    private ImageButton m_menu;
    private long double_touch_border = 500; // Миллисекунды для выяснения был ли двойной клик
    private long last_touch_time = 0;
    private int id_control = 0;
    private Map<Integer, Musical_instrument> instruments;
    private String work_file;

    @SuppressLint({"ClickableViewAccessibility", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_table);

        field = findViewById(R.id.field);

        instruments = new HashMap<>();
        field.setOnTouchListener(get_field_toucher());
        get_system_info();
        get_views_info();
    }

    @Override
    public void onResume() {
        super.onResume();
        field.setFocusableInTouchMode(true);
        field.requestFocus();
        field.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK)
                    get_alert_window_to_menu().show();
                return true;
            }
        });
    }

    public AlertDialog.Builder get_alert_window_to_menu() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Music_table.this);
        builder.setTitle("Переход в меню с проектами");
        builder.setMessage("Нужно ли сохранять файл?");
        builder.setPositiveButton("Сохранить", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                set_views_info();
                Intent t = new Intent(Music_table.this, MainActivity.class);
                startActivity(t);
                dialog.cancel();
            }
        });
        builder.setNegativeButton("Нет", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                clear_history();
                Intent t = new Intent(Music_table.this, MainActivity.class);
                startActivity(t);
                dialog.cancel();
            }
        });
        return builder;
    }

    public void get_system_info() {
        try {
            FileInputStream fileInputStream = openFileInput("system_info.txt");
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                work_file = lines;
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    // Запись информации об инструментах
    public void set_views_info() {
        try {
            FileOutputStream fileOutputStream = openFileOutput(work_file, MODE_PRIVATE);
            for (Map.Entry<Integer, Musical_instrument> entry : instruments.entrySet()) {
                fileOutputStream.write((entry.getValue().To_string() + "\n").getBytes());
            }
            fileOutputStream.close();

        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        clear_history();
    }

    // Стираем информаию об нужности посещения этого файла
    public void clear_history(){
        try {
            FileOutputStream fileOutputStream = openFileOutput("system_info.txt", MODE_PRIVATE);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        try {
            FileOutputStream fileOutputStream = openFileOutput("last_project.txt", MODE_PRIVATE);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    // Если информация осталась в файле истории, то идёт восстановление последней версии
    public boolean need_history_last_file() {
        boolean result = false;
        try {
            FileInputStream fileInputStream = openFileInput("last_project.txt");
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            result = (buffer.readLine() != null);
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    // Считывание из файла сохранённые данные
    public void get_views_info() {
        try {
            String file_name = work_file;
            if (need_history_last_file()) file_name = "last_project.txt";

            FileInputStream fileInputStream = openFileInput(file_name);
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                Create_View(lines);
            }
            set_history_last_file();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    // Сохранение информации для резервного копирования
    public void set_history_last_file() {
        try {
            FileOutputStream fileOutputStream = openFileOutput("last_project.txt", MODE_PRIVATE);
            for (Map.Entry<Integer, Musical_instrument> entry : instruments.entrySet()) {
                fileOutputStream.write((entry.getValue().To_string() + "\n").getBytes());
            }
            fileOutputStream.close();

        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    // Создание инструмента по записи из хроник
    @SuppressLint("ClickableViewAccessibility")
    public void Create_View(String data) {
        String[] data_s = data.split("\n");
        for (String view_info : data_s) {
            String[] view_info_s = view_info.split(" ");

            ImageButton temp_but_1 = new ImageButton(Music_table.this);

            // Возможно потом стоит как-то сделать изображение
//            temp_but_1.setImageDrawable(Drawable.createFromPath("@android:drawable/radiobutton_off_background"));
//            temp_but_1.setImageResource(R.drawable.tap_circle);
//            temp_but_1.colo;


            ConstraintLayout.LayoutParams fieldParams = new ConstraintLayout.LayoutParams
                    (ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
            fieldParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
            fieldParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
            fieldParams.leftMargin = Integer.parseInt(view_info_s[1]);
            fieldParams.topMargin = Integer.parseInt(view_info_s[2]);
            fieldParams.width = Integer.parseInt(view_info_s[5]);
            fieldParams.height = Integer.parseInt(view_info_s[6]);
            temp_but_1.setLayoutParams(fieldParams);

            id_control = Math.max(Integer.parseInt(view_info_s[0]), id_control) + 1;
            temp_but_1.setId(Integer.parseInt(view_info_s[0]));
            temp_but_1.setOnTouchListener(get_music_toucher(field));

            field.addView(temp_but_1);
            instruments.put(Integer.parseInt(view_info_s[0]),
                    new Musical_instrument(Integer.parseInt(view_info_s[0]),
                            Integer.parseInt(view_info_s[1]),
                            Integer.parseInt(view_info_s[2]),
                            Integer.parseInt(view_info_s[3]),
                            Integer.parseInt(view_info_s[4]),
                            Integer.parseInt(view_info_s[5]),
                            Integer.parseInt(view_info_s[6])));
        }
    }

    // Обработчик событий для поля
    public View.OnTouchListener get_field_toucher() {
        return new View.OnTouchListener() {
            @SuppressLint("ResourceType")
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (event.getAction() != MotionEvent.ACTION_DOWN) {
                    return true;
                }

                ImageButton temp_but_1 = new ImageButton(Music_table.this);

                // Возможно потом стоит как-то сделать изображение
//                temp_but_1.setImageDrawable(Drawable.createFromPath("@android:drawable/ic_dialog_dialer")); //"@android:drawable/radiobutton_off_background"));
//                temp_but_1.setImageResource(R.drawable.ic_launcher_foreground);

                // устанавливаем параметры размеров и расположение элемента
                ConstraintLayout.LayoutParams fieldParams = new ConstraintLayout.LayoutParams
                        (ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                // выравнивание по левому краю ConstraintLayout
                fieldParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
                // выравнивание по верхней границе ConstraintLayout
                fieldParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
                // остальные параметры
                fieldParams.leftMargin = (int) event.getX();
                fieldParams.topMargin = (int) event.getY();
                fieldParams.width = 100;
                fieldParams.height = 100;
                // устанавливаем параметры для textView
                temp_but_1.setLayoutParams(fieldParams);

                id_control += 1;
                temp_but_1.setId(id_control);
                // Добавление обработчика действий для инструмента
                temp_but_1.setOnTouchListener(get_music_toucher(field));

                field.addView(temp_but_1);
                Musical_instrument instrument = new Musical_instrument(id_control, (int) event.getX(), (int) event.getY());
                instruments.put(id_control, instrument);

                set_history_last_file();

                return true;
            }
        };
    }

    // Создание обработчика действий с кнопкой
    public View.OnTouchListener get_music_toucher(ConstraintLayout container) {
        final int[] x_prime = new int[1];
        final int[] y_prime = new int[1];
        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                int x_temp = (int) event.getRawX();
                int y_temp = (int) event.getRawY();

                // Действия инструмента при нажатии на него
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                    x_prime[0] = x_temp - layoutParams.leftMargin;
                    y_prime[0] = y_temp - layoutParams.topMargin;
                    long temp_touch_time = System.currentTimeMillis();

                    // Действия при двойном нажатии
                    if (temp_touch_time - last_touch_time <= double_touch_border) {
                        PopupMenu instrument_menu = new PopupMenu(Music_table.this, view);
                        instrument_menu.getMenuInflater().inflate(R.menu.musical_instrument_menu, instrument_menu.getMenu());

                        instrument_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                if (item.getTitle().toString().equals("Удалить инструмент")) {
                                    field.removeView(view);
                                } else if (item.getTitle().toString().equals("Изменить ширину")) {
                                    get_alert_result("Ширина инструмента",
                                            "Ведите желаемую ширину инструмента (число, большее нуля)",
                                            view);
                                } else if (item.getTitle().toString().equals("Изменить высоту")) {
                                    get_alert_result("Высота инструмента",
                                            "Ведите желаемую высоту инструмента (число, большее нуля)",
                                            view);
                                } else if (item.getTitle().toString().equals("Изменить октаву")) {
                                    get_alert_result("Октава инструмента",
                                            "Ведите желаемую октаву инструмента (число, большее нуля)",
                                            view);
                                } else if (item.getTitle().toString().equals("Изменить ноту")) {
                                    get_alert_result("Нота инструмента",
                                            "Ведите желаемую ноту инструмента (число, большее нуля)",
                                            view);
                                }
                                return true;
                            }
                        });
                        instrument_menu.show();
                    }
                    last_touch_time = temp_touch_time;
                }
                // Действия инструмента при попытке его перетащить
                else if (event.getAction() == MotionEvent.ACTION_MOVE
                        && x_temp - x_prime[0] + view.getWidth() <= container.getWidth()
                        && y_temp - y_prime[0] + view.getHeight() <= container.getHeight()
                        && x_temp - x_prime[0] >= 0
                        && y_temp - y_prime[0] >= 0) {
                    ConstraintLayout.LayoutParams layoutParams =
                            (ConstraintLayout.LayoutParams) view.getLayoutParams();
                    layoutParams.leftMargin = x_temp - x_prime[0];
                    layoutParams.topMargin = y_temp - y_prime[0];
                    view.setLayoutParams(layoutParams);

                    Objects.requireNonNull(instruments.get(view.getId())).x_position = x_temp - x_prime[0];
                    Objects.requireNonNull(instruments.get(view.getId())).y_position = y_temp - y_prime[0];
                }
                container.invalidate();

                return true;
            }
        };
    }

    // Вызов всплывающего окна пользователю для ввода
    public void get_alert_result(String title, String message, View view) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        AlertDialog.Builder builder = new AlertDialog.Builder(Music_table.this);
        builder.setTitle(title);
        builder.setMessage(message);

        EditText input_text = new EditText(Music_table.this);
        input_text.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(input_text);

        builder.setPositiveButton("Подтвердить", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog_, int whichButton) {
                if (String.valueOf(input_text.getText()).isEmpty()
                        || Integer.parseInt(String.valueOf(input_text.getText())) <= 0)
                    Toast.makeText(Music_table.this, "Некорректный ввод", Toast.LENGTH_SHORT).show();
                else if (Objects.equals(title, "Ширина инструмента")) {
                    int new_width = Integer.parseInt(String.valueOf(input_text.getText()));
                    layoutParams.width = new_width;
                    Objects.requireNonNull(instruments.get(view.getId())).width = new_width;
                } else if (Objects.equals(title, "Высота инструмента")) {
                    int new_height = Integer.parseInt(String.valueOf(input_text.getText()));
                    layoutParams.height = new_height;
                    Objects.requireNonNull(instruments.get(view.getId())).height = new_height;
                } else if (Objects.equals(title, "Октава инструмента")) {
                    int new_octave = Integer.parseInt(String.valueOf(input_text.getText()));
                    Objects.requireNonNull(instruments.get(view.getId())).octave = new_octave;
                } else if (Objects.equals(title, "Нота инструмента")) {
                    int new_note = Integer.parseInt(String.valueOf(input_text.getText()));
                    Objects.requireNonNull(instruments.get(view.getId())).note = new_note;
                }
                view.setLayoutParams(layoutParams);
                set_history_last_file();
                dialog_.cancel();
            }
        });

        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog_, int whichButton) {
                dialog_.cancel();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void get_main_menu_toucher(View v) {
        PopupMenu main_menu = new PopupMenu(Music_table.this, v);
        main_menu.getMenuInflater().inflate(R.menu.main_menu, main_menu.getMenu());

        main_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getTitle().toString().equals("Сохранить")) {
                    set_views_info();
                } else if (item.getTitle().toString().equals("Вернуться в меню")) {
                    get_alert_window_to_menu().show();
                }
                return true;
            }
        });
        main_menu.show();
    }
}
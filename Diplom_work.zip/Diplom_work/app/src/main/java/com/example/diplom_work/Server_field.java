package com.example.diplom_work;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiInfo;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.text.format.Formatter;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;

import android.media.midi.*;

//import javax.sound.midi.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
//import androidmidilib.*;
//import com.leff.midi;
//import com.google.*;
import com.leff.midi.*;
import com.leff.midi.event.MidiEvent;
import com.leff.midi.event.NoteOff;
import com.leff.midi.event.NoteOn;

import kotlin.sequences.Sequence;

public class Server_field extends AppCompatActivity {

    public class Tackt implements Comparable<Tackt> {
        public int note;
        public int octave;
        public int tackt_number;

        public Tackt(int note, int octave, int tackt_number) {
            this.note = note;
            this.octave = octave;
            this.tackt_number = tackt_number;
        }

        @Override
        public int compareTo(Tackt another_tackt) {
            return this.tackt_number - ((Tackt) another_tackt).tackt_number;
        }

        @Override
        public String toString() {
            return this.octave + " " + this.note + " " + this.tackt_number;
        }
    }

    private TextView invite_code;
    private TextView file_path;
    private TextView temp_now;
    private Button file_picker;
    private Button change_temp;
    private String addr;
    private boolean stop_server_for_server;
    private HashMap<String, String> coding_alf;
    private HashMap<String, String> parts;
    private HashMap<String, String> id_to_partitas;
    private ArrayList<String> players = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    final Handler handler = new Handler();
    ReentrantLock locker = new ReentrantLock();

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 10 && resultCode == RESULT_OK && data != null)
            file_path.setText(Objects.requireNonNull(data.getData()).getPath());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server_field);

        ListView projectsList = findViewById(R.id.connection_players);
        players.add("Main_player");
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, players);
        projectsList.setAdapter(adapter);
        stop_server_for_server = false;

        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        addr = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress()); // Не обрабатывает ipv6-адреса

        create_coding_alf();
        parts = new HashMap<>();

        invite_code = findViewById(R.id.invite_code);
        invite_code.setText(to_code_invite(addr));
        file_path = findViewById(R.id.file_path);
        file_picker = findViewById(R.id.file_picker);
        change_temp = findViewById(R.id.changer_temp);
        temp_now = findViewById(R.id.temp_now);

        file_picker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent FileIntent = new Intent(Intent.ACTION_GET_CONTENT);
                FileIntent.setType("*/*");
                FileIntent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(FileIntent, "Выберите файл"), 10);
            }
        });

        change_temp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Server_field.this);
                builder.setTitle("Темп исполнения мелодии");
                builder.setMessage("введиье желаемый темп");
                EditText input_text = new EditText(Server_field.this);
                input_text.setInputType(InputType.TYPE_CLASS_NUMBER);
                builder.setView(input_text);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int new_temp = Integer.parseInt(input_text.getText().toString());
                        if (new_temp > 0) temp_now.setText(String.valueOf(new_temp));
                        dialog.cancel();
                    }
                });
                builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        startServerSocket();
    }

    private void startServerSocket() {

        Thread thread = new Thread(new Runnable() {

            @SuppressLint("SimpleDateFormat")
            @Override
            public void run() {
                try {
                    ExecutorService executorService = Executors.newFixedThreadPool(100);
                    ServerSocket ss = new ServerSocket(8999, 100, InetAddress.getByName(addr));
                    ss.setSoTimeout(3600000);

                    while (true) {
                        // Прослушка сообщений
                        Socket s = ss.accept();
                        executorService.execute(new ConnectionHandler(s, ss));
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    public class ConnectionHandler implements Runnable {

        private Socket s;
        private ServerSocket ss;
        private ReentrantLock locker_private;

        public ConnectionHandler(Socket s, ServerSocket ss) {
            this.s = s;
            this.ss = ss;
            locker_private = locker;
        }

        @SuppressLint("SimpleDateFormat")
        public void run() {
            // locker_private.lock();
            try {
                DataInputStream in = new DataInputStream(s.getInputStream());
                String stringData = in.readUTF();
                DataOutputStream out = new DataOutputStream(s.getOutputStream());

                locker_private.lock();
                if (!Objects.equals(stringData.split("\\|")[0], "part 1") &&
                        !parts.containsKey(stringData.split("\\|")[1])) {
                    parts.put(stringData.split("\\|")[1], stringData.split("\\|")[3]);
                    players.add("Игрок №" + stringData.split("\\|")[1]);
                } else
                    out.writeUTF(new SimpleDateFormat("mm:ss:S").format(System.currentTimeMillis()));

                locker_private.unlock();

                update_ui();

                while (Objects.equals(stringData.split("\\|")[0], "part 2") && !stop_server_for_server) {
                }
                if (stop_server_for_server)
                    out.writeUTF(id_to_partitas.get(stringData.split("\\|")[1])); // Нужно отправить партитуру (учесть, что первый игрок - это сервер)

                s.close();
                if (stop_server_for_server) ss.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
//            finally {
//                locker_private.unlock();
//            }
        }
    }

    public void begin_game(View v) throws IOException {
        stop_server_for_server = true;
        create_partita();
        Toast.makeText(this, "You did it!", Toast.LENGTH_LONG).show();
//        Intent t = new Intent(Server_field.this, Player_field.class);
//        startActivity(t);
    }

    public void update_ui() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                adapter.notifyDataSetChanged();
            }
        });
    }

    // Создание партитурдля игроков
    public void create_partita() throws IOException {
        HashSet<String> notes_set = new HashSet<String>(); // Множество требуемых нот
        ArrayList<Tackt> tackts = new ArrayList<Tackt>(); // Здесь хранится время в тактах

        // Так как у меня нет времени и сил, сделаю несколько мелодий в asserts
        // Включаться будет случайная
        AssetManager assetManager = getAssets();
        InputStream file = assetManager.open("Кузнечик.mid");
        MidiFile midi = new MidiFile(file);
        int tackt_len = midi.getResolution(); // Длина такта
        int temp = Integer.parseInt(temp_now.getText().toString());
        float q_note_time = (float) 60 / temp;
        double rest_time = 0.5;

        int count_first_error = 0; // Кол-во нот, отсутствующих у игроков
        int count_second_error = 0; // Кол-во нот, которые игроки не могу проиграть

        // Партитуры для игроков (элемент партитуры - это тройка: октава, нота и их время исполнения)
        ArrayList<StringBuilder> partitas = new ArrayList<StringBuilder>();

        for (MidiTrack track : midi.getTracks()) {
            Iterator<MidiEvent> it = track.getEvents().iterator();
            while (it.hasNext()) {
                MidiEvent E = it.next();
                if (E.getClass().equals(NoteOn.class) && ((NoteOn) E).getVelocity() > 0) {
                    int key = ((NoteOn) E).getNoteValue();
                    int octave = (key / 12) - 1;
                    int note = key % 12;
                    Tackt temp_tackt = new Tackt(note, octave, (int) (E.getTick() / tackt_len));
                    notes_set.add(temp_tackt.octave + " " + temp_tackt.note);
                    tackts.add(temp_tackt);
                }
            }
        }

        Collections.sort(tackts);

        // Отображает последнее исполнение ноты (в секундах) для каждого i-го игрока, по-умлчанию - (-100)
        ArrayList<Float> players_time = new ArrayList<Float>();

        // Сопоставляет порядковый номер игрока его id
        ArrayList<String> players_id = new ArrayList<>();

        for (String key : parts.keySet()) {
            players_time.add((float) -100);
            partitas.add(new StringBuilder());
            players_id.add(key);
        }

        // Каждой ноте список игроков, которые могут её проигрывать
        HashMap<String, ArrayList<Integer>> note_to_players = new HashMap<>();

        // Составляем словарь по всем используемым в мелодии нотам
        for (String s : notes_set) {
            note_to_players.put(s, new ArrayList<>());
        }

        // Каждой ноте сопоставляем список из игроков, которые её могу воспроизвести
        for (int i = 0; i < players_id.size(); i++) {
            String[] player_s = Objects.requireNonNull(parts.get(players_id.get(i))).split("\\|");
            for (String s : player_s) {
                if (!note_to_players.containsKey(s)) continue;
                ArrayList<Integer> note_now = note_to_players.get(s);
                note_now.add(i);
                note_to_players.remove(s);
                note_to_players.put(s, note_now);
            }
        }

        // Проверяем мелодию на то, что у игроков есть все нужные виды нот
        for (String s : notes_set)
            if (Objects.requireNonNull(note_to_players.get(s)).isEmpty())
                count_first_error += 1;

        // Проверяем, что игроки могут воспроизвести все ноты в нужный момент
        for (int i = 0; i < tackts.size(); i++) {
            Tackt tackt = tackts.get(i);
            ArrayList<Integer> temp_players = note_to_players.get(tackt.octave + " " + tackt.note);
            float time = tackt.tackt_number * q_note_time;
            boolean was_replace = false;
            assert temp_players != null;
            for (Integer j : temp_players) {
                if (players_time.get(j) + rest_time <= time && time != players_time.get(j)) {
                    players_time.set(j, time);
                    if (!Objects.equals(partitas.get(j), new StringBuilder())) partitas.get(j).append("|");
                    partitas.get(j).append(tackt.octave).append(" ").append(tackt.note).append(" ").append(time);
                    was_replace = true;
                    break;
                }
            }
            if (!was_replace)
                count_second_error += 1;
        }

        for (int i = 0; i < partitas.size(); i++) {
            id_to_partitas.put(players_id.get(i), partitas.get(i).toString());
        }
    }

    private void create_coding_alf() {
        coding_alf = new HashMap<>();
//        coding_alf.put("0", "A");
//        coding_alf.put("1", "B");
//        coding_alf.put("2", "C");
//        coding_alf.put("3", "D");
//        coding_alf.put("4", "E");
//        coding_alf.put("5", "F");
//        coding_alf.put("6", "G");
//        coding_alf.put("7", "H");
//        coding_alf.put("8", "I");
//        coding_alf.put("9", "J");
//        coding_alf.put("10", "K");
//        coding_alf.put("11", "L");
//        coding_alf.put("12", "M");
//        coding_alf.put("13", "N");
//        coding_alf.put("14", "O");
//        coding_alf.put("15", "P");
//        coding_alf.put("16", "Q");
//        coding_alf.put("17", "R");
//        coding_alf.put("18", "S");
//        coding_alf.put("19", "T");
//        coding_alf.put("20", "U");
//        coding_alf.put("21", "V");
//        coding_alf.put("22", "W");
//        coding_alf.put("23", "X");
//        coding_alf.put("24", "Y");
//        coding_alf.put("25", "Z");
//        coding_alf.put("26", "0");
//        coding_alf.put("27", "1");
//        coding_alf.put("28", "2");
//        coding_alf.put("29", "3");
//        coding_alf.put("30", "4");
//        coding_alf.put("31", "5");
//
//        coding_alf.put("A", "0");
//        coding_alf.put("B", "1");
//        coding_alf.put("C", "2");
//        coding_alf.put("D", "3");
//        coding_alf.put("E", "4");
//        coding_alf.put("F", "5");
//        coding_alf.put("G", "6");
//        coding_alf.put("H", "7");
//        coding_alf.put("I", "8");
//        coding_alf.put("J", "9");
//        coding_alf.put("K", "10");
//        coding_alf.put("L", "11");
//        coding_alf.put("M", "12");
//        coding_alf.put("N", "13");
//        coding_alf.put("O", "14");
//        coding_alf.put("P", "15");
//        coding_alf.put("Q", "16");
//        coding_alf.put("R", "17");
//        coding_alf.put("S", "18");
//        coding_alf.put("T", "19");
//        coding_alf.put("U", "20");
//        coding_alf.put("V", "21");
//        coding_alf.put("W", "22");
//        coding_alf.put("X", "23");
//        coding_alf.put("Y", "24");
//        coding_alf.put("Z", "25");
//        coding_alf.put("0", "26");
//        coding_alf.put("1", "27");
//        coding_alf.put("2", "28");
//        coding_alf.put("3", "29");
//        coding_alf.put("4", "30");
//        coding_alf.put("5", "31");

        coding_alf.put("0", "k");
        coding_alf.put("1", "h");
        coding_alf.put("2", "y");
        coding_alf.put("3", "s");
        coding_alf.put("4", "t");
        coding_alf.put("5", "l");
        coding_alf.put("6", "v");
        coding_alf.put("7", "m");
        coding_alf.put("8", "z");
        coding_alf.put("9", "c");
        coding_alf.put(".", "p");

        coding_alf.put("k", "0");
        coding_alf.put("h", "1");
        coding_alf.put("y", "2");
        coding_alf.put("s", "3");
        coding_alf.put("t", "4");
        coding_alf.put("l", "5");
        coding_alf.put("v", "6");
        coding_alf.put("m", "7");
        coding_alf.put("z", "8");
        coding_alf.put("c", "9");
        coding_alf.put("p", ".");
    }

    private String to_code_invite(String s) {
        StringBuilder new_s = new StringBuilder();
        for (int i = 0; i < s.length(); i++)
            new_s.append(coding_alf.get(String.valueOf(s.charAt(i))));
        return new_s.toString();
    }

    private String to_decode_invite(String s) {
        StringBuilder new_s = new StringBuilder();
        for (int i = 0; i < s.length(); i++)
            new_s.append(coding_alf.get(String.valueOf(s.charAt(i))));
        return new_s.toString();
    }
}
package com.example.diplom_work;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Player_field extends AppCompatActivity {

    private class Musical_instrument {
        private int note;
        private int octave;
        private int id;
        private int x_position;
        private int y_position;
        private int width;
        private int height;

        public Musical_instrument(int id, int x, int y) {
            this.id = id;
            this.octave = -1;
            this.note = -1;
            this.width = 100;
            this.height = 100;
            this.x_position = x;
            this.y_position = y;
        }

        public Musical_instrument(int id, int x, int y, int octave, int note, int width, int height) {
            this.id = id;
            this.octave = octave;
            this.note = note;
            this.width = width;
            this.height = height;
            this.x_position = x;
            this.y_position = y;
        }

        public String To_string() {
            return this.id + " " + x_position + " " + y_position + " " + octave + " " + note + " " + width + " " + height;
        }

    }

    private ConstraintLayout field;
    private String work_file;
    private int id_control = 0;
    private Map<Integer, Player_field.Musical_instrument> instruments;
    private HashMap<String, String> coding_alf;
    private String addr = null; // ip-адрес сервера (пулучить через alert-окно кода приглашения)
    private static String super_code = null; // Уникальный код игрока
    private boolean was_answer = false; // Показывает была ли передана игроку партия
    final Handler handler = new Handler();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_field);

        Random rand = new Random();
        field = findViewById(R.id.p_field);
        instruments = new HashMap<>();
        super_code = String.valueOf(rand.nextInt(1000000000));
        Toast.makeText(this, super_code, Toast.LENGTH_SHORT).show();

        get_system_info();
        get_views_info();
        get_invite_code();
        start_player();
    }

    // Создание поля----
    private void get_system_info() {
        try {
            FileInputStream fileInputStream = openFileInput("system_info.txt");
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                work_file = lines;
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    private void get_views_info() {
        try {
            FileInputStream fileInputStream = openFileInput(work_file);
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                Create_View(lines);
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public void Create_View(String data) {
        String[] data_s = data.split("\n");
        for (String view_info : data_s) {
            String[] view_info_s = view_info.split(" ");

            ImageButton temp_but_1 = new ImageButton(Player_field.this);

            // Возможно потом стоит как-то сделать изображение
//            temp_but_1.setImageDrawable(Drawable.createFromPath("@android:drawable/radiobutton_off_background"));

            ConstraintLayout.LayoutParams fieldParams = new ConstraintLayout.LayoutParams
                    (ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
            fieldParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
            fieldParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
            fieldParams.leftMargin = Integer.parseInt(view_info_s[1]);
            fieldParams.topMargin = Integer.parseInt(view_info_s[2]);
            fieldParams.width = Integer.parseInt(view_info_s[5]);
            fieldParams.height = Integer.parseInt(view_info_s[6]);
            temp_but_1.setLayoutParams(fieldParams);

            id_control = Math.max(Integer.parseInt(view_info_s[0]), id_control) + 1;
            temp_but_1.setId(Integer.parseInt(view_info_s[0]));

            field.addView(temp_but_1);
            instruments.put(Integer.parseInt(view_info_s[0]),
                    new Player_field.Musical_instrument(Integer.parseInt(view_info_s[0]),
                            Integer.parseInt(view_info_s[1]),
                            Integer.parseInt(view_info_s[2]),
                            Integer.parseInt(view_info_s[3]),
                            Integer.parseInt(view_info_s[4]),
                            Integer.parseInt(view_info_s[5]),
                            Integer.parseInt(view_info_s[6])));
        }
    }
    //----
    //Клиентская часть----

    private void get_invite_code() {
        create_coding_alf();
        AlertDialog.Builder builder = new AlertDialog.Builder(Player_field.this);
        builder.setTitle("Код лобби")
                .setMessage("Введите код приглашения");
        EditText input_text = new EditText(this);
        input_text.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input_text);
        builder.setCancelable(false);
        builder.setPositiveButton("Готово", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                addr = to_decode_invite(input_text.getText().toString());
                dialog.cancel();
            }
        });
        builder.show();
    }

    private String to_decode_invite(String s) {
        StringBuilder new_s = new StringBuilder();
        for (int i = 0; i < s.length(); i++)
            new_s.append(coding_alf.get(String.valueOf(s.charAt(i))));
        return new_s.toString();
    }

    private void create_coding_alf() {
        coding_alf = new HashMap<>();
        coding_alf.put("0", "k");
        coding_alf.put("1", "h");
        coding_alf.put("2", "y");
        coding_alf.put("3", "s");
        coding_alf.put("4", "t");
        coding_alf.put("5", "l");
        coding_alf.put("6", "v");
        coding_alf.put("7", "m");
        coding_alf.put("8", "z");
        coding_alf.put("9", "c");
        coding_alf.put(".", "p");

        coding_alf.put("k", "0");
        coding_alf.put("h", "1");
        coding_alf.put("y", "2");
        coding_alf.put("s", "3");
        coding_alf.put("t", "4");
        coding_alf.put("l", "5");
        coding_alf.put("v", "6");
        coding_alf.put("m", "7");
        coding_alf.put("z", "8");
        coding_alf.put("c", "9");
        coding_alf.put("p", ".");
    }

    private void start_player() {
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    while (addr == null) {}
                    String t1 = null;
                    String t2 = null;
                    String t3 = null;
                    for (int i=0; i<2; i++) {
                        Socket s = new Socket(addr, 8999);
                        s.setSoTimeout(3600000);

                        OutputStream outToServer = s.getOutputStream();
                        DataOutputStream out = new DataOutputStream(outToServer);

                        String player_info = to_out_instrument(String.valueOf(i + 1), null);
                        if (i == 0) t1 = player_info.split("\\|")[2];
                        if (i == 1) {
                            t3 = player_info.split("\\|")[2];
                            String delta_time = String.valueOf((2 * date_to_int(t2) - date_to_int(t1) - date_to_int(t3)) / 2);
                            player_info = to_out_instrument(String.valueOf(i + 1), delta_time);
                        }

                        out.writeUTF(player_info);

                        InputStream inFromServer = s.getInputStream();
                        DataInputStream in = new DataInputStream(inFromServer);

                        String answer = in.readUTF();
                        if (i == 0) {
                            t2 = answer;
                        }
                        test_part(answer);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    @SuppressLint("SimpleDateFormat")
    private String to_out_instrument(String part_number, String delta_time) {
        StringBuilder out_string = new StringBuilder("part " +  part_number + "|" + super_code + "|");

        if (delta_time != null) out_string.append(delta_time);
        else out_string.append(new SimpleDateFormat("mm:ss:S").format(System.currentTimeMillis()));

        for (Map.Entry<Integer, Musical_instrument> entry : instruments.entrySet()) {
            String[] value = entry.getValue().To_string().split(" ");
            out_string.append("|").append(value[3]).append(" ").append(value[4]);
        }
        return out_string.toString();
    }

    // После реализации правильного подсчёта рассинхрона с миллисекундами реализовать метод
    private int date_to_int(String date) {
        String[] date_s = date.split(":");
        return Integer.parseInt(date_s[2]) +
                1000 * Integer.parseInt(date_s[1]) +
                1000 * 60 * Integer.parseInt(date_s[0]);
    }

    public void test_part(String p) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(Player_field.this, p, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
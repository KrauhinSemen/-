package com.example.diplom_work;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<String> projects = new ArrayList<String>();
    private ArrayAdapter<String> adapter;
    private String type_choose_instrument;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView projectsList = findViewById(R.id.projectsList);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, projects);
        projectsList.setAdapter(adapter);
        type_choose_instrument = "base";

        // Обработчик действий при нажатии на конкретный проект
        projectsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    FileOutputStream fileOutputStream = openFileOutput("system_info.txt", MODE_PRIVATE);
                    fileOutputStream.write((projectsList.getItemAtPosition(position).toString() + ".txt").getBytes());
                    fileOutputStream.close();
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                }
                // Выбор куда переместиться при выборе инструмента
                if (Objects.equals(type_choose_instrument, "base")) {
                    Intent t = new Intent(MainActivity.this, Music_table.class);
                    startActivity(t);
                }
                else if (Objects.equals(type_choose_instrument, "server")) {
                    Intent t = new Intent(MainActivity.this, Server_field.class);
                    startActivity(t);
                }
                else if (Objects.equals(type_choose_instrument, "client")) {
                    Intent t = new Intent(MainActivity.this, Player_field.class);
                    startActivity(t);
                }
            }
        });

        // Работа с файлами --------
        projectsList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                PopupMenu project_menu = new PopupMenu(MainActivity.this, view);
                project_menu.getMenuInflater().inflate(R.menu.project_menu, project_menu.getMenu());

                project_menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().toString().equals("Удалить проект")) {
                            delete_file(projectsList.getItemAtPosition(position).toString());
                        } else if (item.getTitle().toString().equals("Создать копию")) {
                            make_copy(projectsList.getItemAtPosition(position).toString());
                        }
                        return true;
                    }
                });
                project_menu.show();
                return true;
            }
        });
        create_system_files();
    }

    public void add_project(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Добавление пректа")
                .setMessage("Введите название нового проекта");
        EditText input_text = new EditText(this);
        input_text.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input_text);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (input_text.getText().toString().equals("")) dialog.cancel();
                else {
                    create_file(input_text.getText().toString(), false);
                }
            }
        });
        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    public void create_system_files() {
        try {
            FileOutputStream fileOutputStream = openFileOutput("project_names.txt", MODE_APPEND);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        try {
            FileOutputStream fileOutputStream = openFileOutput("last_project.txt", MODE_APPEND);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        try {
            FileOutputStream fileOutputStream = openFileOutput("system_info.txt", MODE_APPEND);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        reborn_projects();

        try {
            FileInputStream fileInputStream = openFileInput("system_info.txt");
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                if (!lines.equals("")) {
                    Intent t = new Intent(MainActivity.this, Music_table.class);
                    startActivity(t);
                }
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

    }

    public void reborn_projects() {
        try {
            FileInputStream fileInputStream = openFileInput("project_names.txt");
            InputStreamReader reader = new InputStreamReader(fileInputStream);
            BufferedReader buffer = new BufferedReader(reader);
            String lines = "";
            while ((lines = buffer.readLine()) != null) {
                create_file(lines, true);
            }
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    public void delete_file(String file_name) {
        projects.remove(file_name);
        deleteFile(file_name + ".txt");
        try {
            FileOutputStream fileOutputStream = openFileOutput("project_names.txt", MODE_PRIVATE);
            for (String element : projects) {
                fileOutputStream.write((element + "\n").getBytes());
            }
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        adapter.notifyDataSetChanged();
    }

    public void make_copy(String file_name) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Копирование пректа")
                .setMessage("Введите название для копии проекта " + file_name);
        EditText input_text = new EditText(this);
        input_text.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input_text);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (input_text.getText().toString().equals("")) dialog.cancel();
                else {
                    String copy_name = input_text.getText().toString();
                    create_file(copy_name, false);
                    try {
                        FileInputStream fileInputStream = openFileInput(file_name + ".txt");
                        InputStreamReader reader = new InputStreamReader(fileInputStream);
                        BufferedReader buffer = new BufferedReader(reader);

                        FileOutputStream fileOutputStream = openFileOutput(copy_name + ".txt", MODE_APPEND);

                        String lines = "";
                        while ((lines = buffer.readLine()) != null) {
                            fileOutputStream.write((lines + "\n").getBytes());
                        }
                        fileOutputStream.close();
                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, "Error_0", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    public void create_file(String file_name, boolean is_reborn) {
        // Проверка того, что имя не соответствует системному имени
        if (Objects.equals(file_name, "system_info") || Objects.equals(file_name, "project_names")) {
            Toast.makeText(this, "Это имя занято системными файлами", Toast.LENGTH_SHORT).show();
            return;
        }

        // Проверка на уникальность имени
        for (String element : projects) {
            if (Objects.equals(element, file_name)) {
                Toast.makeText(this, "Это имя уже занято", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (!is_reborn) {
            try {
                FileOutputStream fileOutputStream = openFileOutput("project_names.txt", MODE_APPEND);
                fileOutputStream.write((file_name + "\n").getBytes());
                fileOutputStream.close();
            } catch (IOException e) {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }
        }

        try {
            FileOutputStream fileOutputStream = openFileOutput(file_name + ".txt", MODE_APPEND);
            fileOutputStream.close();
        } catch (IOException e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        projects.add(0, file_name);
        adapter.notifyDataSetChanged();
    }

    // -------
    // Сервер-клиентная модель -----
    public void to_server(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Предупреждение");
        builder.setMessage("Вы уверены что хотите создать комнату?");
        builder.setPositiveButton("Создать", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                type_choose_instrument = "server";
                Toast.makeText(MainActivity.this, "Выберите инструмент", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    public void to_client(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Предупреждение");
        builder.setMessage("Вы уверены что хотите присоединиться к другой комнате?");
        builder.setPositiveButton("Присоединится", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Перейти в окно исполнителя, скопировав рассановку инструмента
                // Присоединиться к серверу, передав ему всю информацию
                type_choose_instrument = "client";
                Toast.makeText(MainActivity.this, "Выберите инструмент", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    public void to_online(View view) {
        final String[] listItems = new String[]{"C", "C++", "JAVA", "PYTHON"};
        final String[] checkedItem = {null};

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        builder.setTitle("Выбери роль");

        builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                checkedItem[0] = listItems[which];
            }
        });

        builder.setPositiveButton("Готово", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, checkedItem[0], Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        builder.show();
    }
}